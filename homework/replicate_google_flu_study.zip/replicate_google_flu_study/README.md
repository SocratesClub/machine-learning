Replicating the Google Flu study with CDC's ili data of Mid Atlantic region
